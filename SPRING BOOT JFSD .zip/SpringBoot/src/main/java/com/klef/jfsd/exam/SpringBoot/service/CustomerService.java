package com.klef.jfsd.exam.SpringBoot.service;

import java.util.List;

import com.klef.jfsd.exam.SpringBoot.model.Customer;

public interface CustomerService {
	  List<Customer> getAllCustomers();

}
